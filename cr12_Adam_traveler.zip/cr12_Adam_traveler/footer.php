<div class="footer bg-secondary py-3">
        
        <div class="social-icons d-flex flex-row text-center align-items-center justify-content-center m-auto">
            <span>Facebook</span><a href="#" class="nav-link text-dark fa fa-facebook"></a>
            <span>Twitter</span><a href="#" class="nav-link text-dark fa fa-twitter"></a>
            <span>Instagram</span><a href="#" class="nav-link text-dark fa fa-instagram"></a>

        </div>
        <hr class="text-dark">
        <div class="cr d-flex flex-row align-items-center justify-content-center m-auto">
            <span><i class="fa fa-copyright mr-1"></i></span>
            <h3 class="text-center">2020-Adam-All rights reserved</h3>
        </div>
    </div>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"
        integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous">
    </script>
<?php wp_footer();?>
    
</body>

</html>