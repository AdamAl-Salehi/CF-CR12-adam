<?php get_header();?>

<div class="container">
    <?php if(have_posts()):?>

    <div class="container mt-5">

        <?php while(have_posts()): the_post();?>

        <?php if(has_post_thumbnail()):?>
        <div><?php the_post_thumbnail('large');?></div>
        <?php endif;?> <br>
        <a class="nav-link text-dark p-0 mb-2">
            <h2 class="mb-2"><?php the_title();?></h3><br>
        </a>
        <p class="date"><?php the_time("F j,Y g:i a");?> by <?php the_author();?></p>

        <hr>

        <div class="description mb-5"><?php the_content(); ?></div>

        <div class="comments"><?php comments_template();?></div>

        <?php endwhile;?>
    </div>
    <?php endif;?>
</div>

<?php get_footer();?>