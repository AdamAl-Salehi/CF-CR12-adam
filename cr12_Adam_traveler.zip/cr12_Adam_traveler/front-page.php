<?php get_header();?>

<div class="container">
    <?php if(have_posts()):?>

    <div class="row  mt-5">

        <?php while(have_posts()): the_post();?>
        <div class="col-lg-4 col-sm-11 col-md-11  mb-3 ">
            <div class="card border-0">
                <img class="img-fluid card-img m-auto"
                    src="https://static.travelworks.de/media/header/work-and-travel/seo/work-and-travel-organisation-header-neu-lg.jpg"
                    alt="placeholder">
                <div class="card-body text-center">
                    <a href="<?php the_permalink();?>" class="nav-link text-dark p-0">
                        <h3 class="card-title "><?php the_title();?></h3>
                    </a>
                    <hr class="card-hr">
                    <p class="card-description"><?php the_excerpt(); ?></p>
                    <p class="card-date"><?php the_time("F j,Y g:i a");?></p>
                </div>
            </div>
        </div>
        <?php endwhile;?>
    </div>
    <?php endif;?>
    <?php
      if(is_active_sidebar('sidebar')):
     dynamic_sidebar('sidebar');
     endif;  
?>
</div>

<?php get_footer();?>